// © 2026 MiBusSantiago by Feguens Doralus
// Prohibida su copia, distribución o modificación sin autorización .
//
// NOTA DE OPTIMIZACIÓN: se eliminó "app/build.gradle" (versión Groovy) porque
// tener build.gradle y build.gradle.kts a la vez en el mismo módulo hace que
// Gradle falle al configurar el proyecto. Este .kts es el único archivo de
// build del módulo :app.

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
    id("com.google.firebase.appdistribution")
}

android {
    namespace = "cl.feguens.mibussantiago"
    compileSdk = 34

    defaultConfig {
        applicationId = "cl.feguens.mibussantiago"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        // Reducción de recursos de idiomas innecesarios de librerías de terceros (Firebase, Play Services)
        resourceConfigurations += listOf("es", "en")
    }

    signingConfigs {
        create("release") {
            storeFile = file("../keystore/mibussantiago-release.jks")
            // OPTIMIZACIÓN/SEGURIDAD: las contraseñas ya no están hardcodeadas aquí,
            // se leen desde gradle.properties (o variables de entorno en CI).
            storePassword = (project.findProperty("MIBUS_KEYSTORE_PASSWORD") as String?)
                ?: System.getenv("MIBUS_KEYSTORE_PASSWORD") ?: ""
            keyAlias = (project.findProperty("MIBUS_KEY_ALIAS") as String?)
                ?: System.getenv("MIBUS_KEY_ALIAS") ?: ""
            keyPassword = (project.findProperty("MIBUS_KEY_PASSWORD") as String?)
                ?: System.getenv("MIBUS_KEY_PASSWORD") ?: ""
        }
    }

    buildTypes {
        getByName("debug") {
            isDebuggable = true

            // Configuración del plugin de Firebase App Distribution en Kotlin DSL
            firebaseAppDistribution {
                appId = "1:557395135688:android:312770249c628f9b4169fd"
                groups = "Equipo-de-Desarrollo, Testers-QA"
                releaseNotes = "Compilación oficial MiBus Santiago para pruebas internas y QA."
                // serviceCredentialsFile = "$rootDir/service-account-key.json"
            }
        }

        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            // Habilita R8 para ofuscación y reducción de código muerto
            isMinifyEnabled = true
            // Elimina recursos gráficos, layouts y strings no referenciados
            isShrinkResources = true
            // Archivo de optimización agresiva y reglas personalizadas
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    // Exclusión de metadatos duplicados para reducir tamaño y evitar colisiones
    packaging {
        resources {
            excludes += listOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/LICENSE*",
                "/META-INF/NOTICE*",
                "/META-INF/INDEX.LIST",
                "/META-INF/DEPENDENCIES"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2023.10.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.navigation:navigation-compose:2.7.5")
    implementation("com.google.android.gms:play-services-maps:18.2.0")
    implementation("com.google.maps.android:maps-compose:4.3.3")
    implementation("com.google.android.gms:play-services-location:21.1.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")
    implementation("com.google.android.gms:play-services-ads:22.6.0")

    // Firebase BOM y Credential Manager
    implementation(platform("com.google.firebase:firebase-bom:32.7.2"))
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-firestore-ktx")
    implementation("androidx.credentials:credentials:1.2.2")
    implementation("androidx.credentials:credentials-play-services-auth:1.2.2")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
}