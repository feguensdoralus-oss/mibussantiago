// © 2026 MiBusSantiago by Feguens Doralus
// Prohibida su copia, distribución o modificación sin autorización .

# Keystore de Firma Oficial - MiBusSantiago

- **Archivo Keystore**: `mibussantiago-release.jks` (también disponible como `mibussantiago-release.keystore`)
- **Alias de Clave**: `mibussantiago`
- **Contraseñas**: definidas en `gradle.properties` (MIBUS_KEYSTORE_PASSWORD / MIBUS_KEY_PASSWORD = `mibussantiago2026`), ya no hardcodeadas en el build.gradle.
- **Algoritmo**: RSA 2048-bit (PKCS12 / JKS Standard)
- **Validez**: 10.000 días (~27 años)
- **Titular / CN**: Feguens Doralus (Santiago, Chile)

## Huellas Digitales del Certificado (Certificate Fingerprints)

Huellas reales verificadas del keystore `mibussantiago-release.jks`:
- **SHA-256**: `3D:B5:4A:0B:21:FA:0E:BF:27:94:F5:83:D7:8F:A8:10:25:F5:37:44:D1:5E:FD:E5:8D:A1:48:D7:BB:FC:02:14`
- **SHA-1**: `C9:39:6D:99:EB:CF:E3:3C:40:C5:02:9E:6D:76:AE:61:90:56:07:63`
- **MD5**: `5E:B9:2F:C9:F6:21:8C:6D:72:EC:50:04:77:2A:D3:DC`

Para verificar en tu consola local:
```bash
keytool -list -v -keystore mibussantiago-release.jks -alias mibussantiago
```
Copia el `SHA1` y `SHA256` que te muestre esa salida y agrégalos en Firebase Console → Configuración del proyecto → tu app Android → "Agregar huella digital".

## Comando para Generar o Recrear con Keytool
```bash
keytool -genkey -v -keystore mibussantiago-release.jks \
    -alias mibussantiago \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -storepass mibussantiago2026 \
    -keypass mibussantiago2026 \
    -dname "CN=Feguens Doralus, OU=MiBusSantiago, O=MiBusSantiago, L=Santiago, ST=Region Metropolitana, C=CL"
```

## Comando para Compilar APK Firmado
```bash
./gradlew assembleRelease
```
El APK firmado listo para instalar o distribuir quedará en `app/build/outputs/apk/release/app-release.apk`.

**IMPORTANTE:** no subas `gradle.properties` con las contraseñas reales a un repositorio público. Agrégalo a `.gitignore` o usa secretos de CI/CD.