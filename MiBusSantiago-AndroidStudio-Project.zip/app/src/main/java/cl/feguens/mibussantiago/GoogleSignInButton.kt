// © 2026 MiBusSantiago by Feguens Doralus
// Prohibida su copia, distribución o modificación sin autorización .

package cl.feguens.mibussantiago

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.launch

@Composable
fun GoogleSignInButton(firebaseManager: FirebaseManager = remember { FirebaseManager() }) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    var showCollisionDialog by remember { mutableStateOf(false) }
    var pendingIdToken by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSuccess by remember { mutableStateOf(false) }

    Column(modifier = Modifier.padding(8.dp)) {
        Button(
            onClick = {
                scope.launch {
                    val googleIdOption = GetGoogleIdOption.Builder()
                        .setFilterByAuthorizedAccounts(false)
                        .setServerClientId(AppConstants.GOOGLE_WEB_CLIENT_ID)
                        .setAutoSelectEnabled(false)
                        .build()

                    val request = GetCredentialRequest.Builder()
                        .addCredentialOption(googleIdOption)
                        .build()

                    try {
                        val result = credentialManager.getCredential(context = context, request = request)
                        val credential = result.credential

                        if (credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                            val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                            val idToken = googleIdTokenCredential.idToken

                            when (val resultLink = firebaseManager.linkWithGoogle(idToken)) {
                                is LinkResult.Success -> {
                                    isSuccess = true
                                    errorMessage = null
                                }
                                is LinkResult.AccountAlreadyExists -> {
                                    pendingIdToken = idToken
                                    showCollisionDialog = true
                                }
                                is LinkResult.Error -> {
                                    errorMessage = resultLink.message
                                }
                            }
                        }
                    } catch (e: GetCredentialException) {
                        e.printStackTrace()
                        errorMessage = "Cancelado por el usuario o error de credenciales"
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Vincular con mi Cuenta de Google")
        }

        if (isSuccess) {
            Spacer(Modifier.height(8.dp))
            Text("¡Cuenta vinculada exitosamente con Google!", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
        }

        errorMessage?.let { msg ->
            Spacer(Modifier.height(8.dp))
            Text(msg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        // Diálogo interactivo para resolución de colisión de cuentas registradas previa
        if (showCollisionDialog && pendingIdToken != null) {
            AlertDialog(
                onDismissRequest = { showCollisionDialog = false },
                title = { Text("Cuenta de Google Ya Registrada") },
                text = {
                    Text("Esta cuenta de Google ya está vinculada a otro perfil en MiBusSantiago. ¿Deseas iniciar sesión directamente con tu cuenta registrada para conservar tus favoritos previos?")
                },
                confirmButton = {
                    TextButton(onClick = {
                        scope.launch {
                            showCollisionDialog = false
                            // CORREGIDO: el operador de no-nulo en Kotlin es "!!", no "!"
                            val switched = firebaseManager.switchToExistingGoogleAccount(pendingIdToken!!)
                            if (switched) {
                                isSuccess = true
                                errorMessage = null
                            } else {
                                errorMessage = "No se pudo iniciar sesión con la cuenta existente."
                            }
                        }
                    }) {
                        Text("Iniciar Sesión")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCollisionDialog = false }) {
                        Text("Cancelar")
                    }
                }
            )
        }
    }
}