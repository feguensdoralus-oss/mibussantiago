// © 2026 MiBusSantiago by Feguens Doralus
// Prohibida su copia, distribución o modificación sin autorización .

package cl.feguens.mibussantiago

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable fun BipScreen() {
    val context = LocalContext.current
    var bipNumber by remember { mutableStateOf("") }

    Column(Modifier.padding(16.dp)) {
        Text("Consultar Saldo BIP", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(20.dp))

        OutlinedTextField(
            value = bipNumber,
            onValueChange = { bipNumber = it },
            label = { Text("N° Tarjeta BIP - 8 dígitos") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(10.dp))

        Button(onClick = {
            // Abre la pagina oficial para consultar
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AppConstants.BIP_CONSULT_URL))
            context.startActivity(intent)
        }, modifier = Modifier.fillMaxWidth()) {
            Text("Consultar en Web Oficial")
        }

        Spacer(Modifier.height(10.dp))

        Button(onClick = {
            // Abre para recargar
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AppConstants.BIP_RECHARGE_URL))
            context.startActivity(intent)
        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)) {
            Text("Recargar BIP Online")
        }

        Spacer(Modifier.height(40.dp))
        Text("Soporte: Feguens Doralus", style = MaterialTheme.typography.labelSmall)
        Text(AppConstants.SUPPORT_EMAIL, style = MaterialTheme.typography.labelSmall)
        Text(AppConstants.SUPPORT_PHONE, style = MaterialTheme.typography.labelSmall)
    }
}