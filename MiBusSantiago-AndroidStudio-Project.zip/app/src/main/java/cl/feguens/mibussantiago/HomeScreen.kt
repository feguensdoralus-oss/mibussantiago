// © 2026 MiBusSantiago by Feguens Doralus
// Prohibida su copia, distribución o modificación sin autorización .

package cl.feguens.mibussantiago
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.google.android.gms.ads.*

@Composable fun HomeScreen(navController: NavController) {
    val context = LocalContext.current

    // OPTIMIZACIÓN: el AdView se crea una sola vez con remember y se destruye
    // en onDispose. Antes se recreaba en cada recomposición y nunca se liberaba,
    // lo que generaba fugas de memoria.
    val adView = remember {
        AdView(context).apply {
            adUnitId = AppConstants.ADMOB_BANNER_ID
            setAdSize(AdSize.BANNER)
            loadAd(AdRequest.Builder().build())
        }
    }
    DisposableEffect(Unit) {
        onDispose { adView.destroy() }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("MiBus Santiago", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(20.dp))
        Button(onClick = { navController.navigate("map") }, modifier = Modifier.fillMaxWidth()) { Text("🚌 Bus más cercano") }
        Spacer(Modifier.height(10.dp))
        Button(onClick = { navController.navigate("bip") }, modifier = Modifier.fillMaxWidth()) { Text("💳 Consultar Saldo BIP") }
        Spacer(Modifier.height(10.dp))
        Button(onClick = { navController.navigate("favorites") }, modifier = Modifier.fillMaxWidth()) { Text("⭐ Favoritos") }
        Spacer(Modifier.weight(1f))
        AndroidView(factory = { adView })
    }
}