// © 2026 MiBusSantiago by Feguens Doralus
// Prohibida su copia, distribución o modificación sin autorización .
//
// OPTIMIZACIÓN: centraliza URLs, IDs y valores repetidos que antes estaban
// dispersos como strings mágicos en distintas pantallas.

package cl.feguens.mibussantiago

object AppConstants {
    const val RED_BUSES_API_URL = "https://api.xor.cl/red/buses"
    const val BIP_CONSULT_URL = "https://www.tarjetabip.cl/consulta-saldo"
    const val BIP_RECHARGE_URL = "https://www.tarjetabip.cl/recarga"
    const val SUPPORT_EMAIL = "feguensdoralus@gmail.com"
    const val SUPPORT_PHONE = "+56 9 3319 8801"
    const val ADMOB_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    const val GOOGLE_WEB_CLIENT_ID =
        "557395135688-5oattooaqvosmag1soshvuu5u4o1bh45.apps.googleusercontent.com"
    const val DEFAULT_LAT = -33.4489
    const val DEFAULT_LON = -70.6693
    const val DEFAULT_MAP_ZOOM = 12f
}