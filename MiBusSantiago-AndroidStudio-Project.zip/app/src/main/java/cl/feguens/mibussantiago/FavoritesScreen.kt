// © 2026 MiBusSantiago by Feguens Doralus
// Prohibida su copia, distribución o modificación sin autorización .

package cl.feguens.mibussantiago

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun FavoritesScreen(firebaseManager: FirebaseManager = remember { FirebaseManager() }) {
    var favoritesList by remember { mutableStateOf(listOf<Map<String, Any>>()) }

    // OPTIMIZACIÓN: DisposableEffect + remove() del listener al salir de composición.
    // Antes se usaba LaunchedEffect sin limpiar el listener de Firestore, lo que
    // podía dejar listeners activos (fuga de memoria / lecturas innecesarias) al
    // navegar fuera de la pantalla.
    DisposableEffect(Unit) {
        val registration = firebaseManager.listenToFavorites { updatedList ->
            favoritesList = updatedList
        }
        onDispose { registration?.remove() }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Tus Paraderos y Buses Favoritos", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))

        GoogleSignInButton(firebaseManager = firebaseManager)

        Spacer(Modifier.height(16.dp))

        if (favoritesList.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No tienes favoritos guardados. Agrega desde el mapa.")
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(favoritesList) { fav ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("Aviso / Bus: ${fav["name"] ?: "Sin Nombre"}", style = MaterialTheme.typography.titleMedium)
                            Text("ID / Patente: ${fav["id"] ?: ""}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}