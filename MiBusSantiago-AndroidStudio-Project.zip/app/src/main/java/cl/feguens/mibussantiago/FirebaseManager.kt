// © 2026 MiBusSantiago by Feguens Doralus
// Prohibida su copia, distribución o modificación sin autorización .

package cl.feguens.mibussantiago

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.tasks.await

sealed class LinkResult {
    object Success : LinkResult()
    data class AccountAlreadyExists(val email: String?) : LinkResult()
    data class Error(val message: String) : LinkResult()
}

class FirebaseManager {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    suspend fun signInAnonymously(): String? {
        return try {
            val result = auth.signInAnonymously().await()
            result.user?.uid
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun getCurrentUserId(): String? = auth.currentUser?.uid

    suspend fun saveFavorite(stopId: String, stopName: String) {
        val userId = getCurrentUserId() ?: signInAnonymously() ?: return
        val favoriteData = mapOf(
            "id" to stopId,
            "name" to stopName,
            "timestamp" to System.currentTimeMillis()
        )
        try {
            db.collection("users").document(userId)
                .collection("favorites").document(stopId)
                .set(favoriteData).await()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // OPTIMIZACIÓN: ahora devuelve el ListenerRegistration para que el llamador
    // pueda remover el listener cuando el composable sale de composición
    // (evita fugas de memoria y listeners duplicados en recomposiciones).
    fun listenToFavorites(onUpdate: (List<Map<String, Any>>) -> Unit): ListenerRegistration? {
        val userId = getCurrentUserId() ?: return null
        return db.collection("users").document(userId)
            .collection("favorites")
            .orderBy("timestamp")
            .addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { it.data }
                    onUpdate(list)
                }
            }
    }

    // Vincular cuenta anónima con Google con detección de FirebaseAuthUserCollisionException
    suspend fun linkWithGoogle(idToken: String): LinkResult {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        return try {
            val currentUser = auth.currentUser
            if (currentUser == null) {
                auth.signInWithCredential(credential).await()
                LinkResult.Success
            } else {
                currentUser.linkWithCredential(credential).await()
                LinkResult.Success
            }
        } catch (e: FirebaseAuthUserCollisionException) {
            e.printStackTrace()
            // Se captura cuando el idToken de Google ya pertenece a otra cuenta de Firebase
            LinkResult.AccountAlreadyExists(e.email)
        } catch (e: Exception) {
            e.printStackTrace()
            LinkResult.Error(e.localizedMessage ?: "Error al vincular cuenta de Google")
        }
    }

    // Método para iniciar sesión directamente con la cuenta existente en caso de colisión
    suspend fun switchToExistingGoogleAccount(idToken: String): Boolean {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        return try {
            auth.signInWithCredential(credential).await()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}