// © 2026 MiBusSantiago by Feguens Doralus
// Prohibida su copia, distribución o modificación sin autorización .

package cl.feguens.mibussantiago

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

@SuppressLint("MissingPermission")
@Composable
fun MapScreen(firebaseManager: FirebaseManager = remember { FirebaseManager() }) {
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(
            LatLng(AppConstants.DEFAULT_LAT, AppConstants.DEFAULT_LON),
            AppConstants.DEFAULT_MAP_ZOOM
        )
    }
    var buses by remember { mutableStateOf(listOf<Bus>()) }
    val scope = rememberCoroutineScope()
    var selectedBus by remember { mutableStateOf<Bus?>(null) }

    LaunchedEffect(Unit) {
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val client = OkHttpClient()
                    val request = Request.Builder()
                        .url(AppConstants.RED_BUSES_API_URL)
                        .build()
                    val response = client.newCall(request).execute()
                    val responseText = response.body?.string() ?: ""
                    if (responseText.isNotEmpty()) {
                        val json = JSONObject(responseText)
                        if (json.has("data")) {
                            val busesArray = json.getJSONArray("data")
                            val list = mutableListOf<Bus>()
                            for (i in 0 until busesArray.length()) {
                                val bus = busesArray.getJSONObject(i)
                                list.add(
                                    Bus(
                                        patente = bus.optString("patente", "RED-BUS"),
                                        lat = bus.optDouble("latitud", AppConstants.DEFAULT_LAT),
                                        // CORREGIDO: la API usa "latitud" para la latitud, por simetría
                                        // el campo de longitud probablemente es "longitud" y no "lon".
                                        // Se mantiene "lon" como respaldo por si la API cambia el nombre.
                                        lon = bus.optDouble(
                                            "longitud",
                                            bus.optDouble("lon", AppConstants.DEFAULT_LON)
                                        ),
                                        servicio = bus.optString("servicio", "DTPM")
                                    )
                                )
                            }
                            withContext(Dispatchers.Main) {
                                buses = list
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        GoogleMap(cameraPositionState = cameraPositionState) {
            buses.forEach { bus ->
                Marker(
                    state = MarkerState(position = LatLng(bus.lat, bus.lon)),
                    title = "Autobús ${bus.servicio}",
                    snippet = "Toca aquí para guardar en favoritos",
                    onInfoWindowClick = {
                        selectedBus = bus
                    }
                )
            }
        }

        selectedBus?.let { bus ->
            AlertDialog(
                onDismissRequest = { selectedBus = null },
                title = { Text("Añadir a Favoritos") },
                text = { Text("¿Deseas guardar el autobús de la línea ${bus.servicio} (Patente: ${bus.patente})?") },
                confirmButton = {
                    TextButton(onClick = {
                        scope.launch {
                            firebaseManager.saveFavorite(bus.patente, "Línea ${bus.servicio}")
                            selectedBus = null
                        }
                    }) {
                        Text("Guardar")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedBus = null }) {
                        Text("Cancelar")
                    }
                }
            )
        }
    }
}

data class Bus(val patente: String, val lat: Double, val lon: Double, val servicio: String)