# © 2026 MiBusSantiago by Feguens Doralus
// Prohibida su copia, distribución o modificación sin autorización .

# ============================================================================
# Reglas Básicas de Optimización y Ofuscación ProGuard / R8
# ============================================================================
-optimizationpasses 5
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose

# Preservar atributos de depuración esenciales (nombres de archivo, líneas, anotaciones)
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,Exceptions

# ============================================================================
# Firebase (Authentication, Firestore, Common SDKs)
# ============================================================================
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**

# Mantener clases POJO / Modelos de datos para Firestore
-keepclassmembers class * {
    @com.google.firebase.firestore.PropertyName <fields>;
    @com.google.firebase.firestore.PropertyName <methods>;
    @com.google.firebase.firestore.Exclude <fields>;
    @com.google.firebase.firestore.Exclude <methods>;
    @com.google.firebase.firestore.ServerTimestamp <fields>;
    @com.google.firebase.firestore.ServerTimestamp <methods>;
}

# Firebase Auth & Google Credential Manager
-keep class com.google.android.gms.auth.api.** { *; }
-keep class androidx.credentials.** { *; }
-keep class com.google.android.libraries.identity.googleid.** { *; }

# ============================================================================
# Google Play Services & Google Maps SDK & Location
# ============================================================================
-keep class com.google.android.gms.maps.** { *; }
-keep interface com.google.android.gms.maps.** { *; }
-keep class com.google.maps.android.** { *; }
-keep class com.google.android.gms.location.** { *; }
-keep class com.google.android.gms.common.** { *; }

# Preservar llamadas nativas JNI requeridas por el renderizador C++ de Google Maps
-keepclasseswithmembernames class * {
    native <methods>;
}

# ============================================================================
# Google Mobile Ads (AdMob)
# ============================================================================
-keep public class com.google.android.gms.ads.** {
    public *;
}
-keep public class com.google.ads.** {
    public *;
}
-dontwarn com.google.android.gms.ads.**

# ============================================================================
# Modelos de Datos del Proyecto MiBusSantiago
# ============================================================================
-keep class cl.feguens.mibussantiago.** { *; }
-keepclassmembers class cl.feguens.mibussantiago.** {
    <fields>;
    <methods>;
}

# ============================================================================
# Retrofit 2, OkHttp 3 & Gson
# ============================================================================
# Retrofit
-dontwarn retrofit2.**
-keep class retrofit2.** { *; }
-keepclasseswithmembers class * {
    @retrofit2.http.* <methods>;
}

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }

# Gson & SerializedName
-keepattributes *Annotation*
-keep class sun.misc.Unsafe { *; }
-keep class com.google.gson.** { *; }
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
    @com.google.gson.annotations.Expose <fields>;
}

# ============================================================================
# Coroutines & Jetpack Compose
# ============================================================================
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}
-dontwarn kotlinx.coroutines.**
-keep class androidx.compose.** { *; }